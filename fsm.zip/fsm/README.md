# `fsm`

Finite State Machine library written in C.
